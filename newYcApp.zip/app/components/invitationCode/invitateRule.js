require('normalize.css/normalize.css');
import React from 'react';
import {
  Card
} from 'amazeui-touch';
import  '../../style/App.css';
import '../../style/rule.css'
import  './invitate.css';
import name_pic from '../../public/img/name_pic.png';
import pay_pic from '../../public/img/pay_pic.png';
import invite_pic from '../../public/img/invite_pic.png';
import {
  render,
  Link
} from 'react-router'

class AppComponent extends React.Component {
  constructor(){
    super();
  }
  componentWillMount(){
    document.title='活动规则'
    document.body.style.background='#fff';
  }
  componentDidMount(){

  }

  render() {
    return (
      <section className="index">
        <div className="activiteRule">
          <Card
            header="活动内容" className="activiteRuleCon fontS15">
            <p>活动时间：2018.09.10-2018.12.10</p>
            活动简介：邀请好友体验快捷键舒适的牦牛出行网约车，好友注册成功后您可获得5元牦牛出行优惠券，
            您的好友将获得10元首单优惠券，每当您的1位好友完成第一次牦牛出行行程并成功支付订单，您便可获得推荐积分奖励。
            积分可无限累积并兑换优惠券，并可用于支付车费。
          </Card>
          <Card header="参与流程" className="activiteRuleCon fontS15">
            <div className="flexBox">
              <div className="">
                <div>01</div>
                <div>
                  进入牦牛出行“推荐有奖”或
                  进入好友的“推荐有奖”链接
                </div>
              </div>
              <div><img src={name_pic} alt=""/></div>
            </div>
            <div className="flexBox">
              <div className="">
                <div>02</div>
                <div>
                  进入牦牛出行“推荐有奖”或
                  进入好友的“推荐有奖”链接
                </div>
              </div>
              <div><img src={invite_pic} alt=""/></div>
            </div>
            <div className="">
              <div>03</div>
              <div>
                进入牦牛出行“推荐有奖”或
                进入好友的“推荐有奖”链接
              </div>
            </div>

            <div className="flexBox">
              <div className="">
                <div>04</div>
                <div>
                  进入牦牛出行“推荐有奖”或
                  进入好友的“推荐有奖”链接
                </div>
              </div>
              <div><img src={pay_pic} alt=""/></div>
            </div>
            <div className="">
              <div>05</div>
              <div>
                进入牦牛出行“推荐有奖”或
                进入好友的“推荐有奖”链接
              </div>
            </div>

          </Card>
        </div>


        <div className="rule-explain bgcolorW padding2 fontSize163">
          <h3>活动说明</h3>
          <p><span>*</span>未使用过牦牛出行的好友，可通过您分享的推荐链接领取牦牛出行优惠券（券有效期为7天）</p>
          <p>
            <span>*</span>
            您的好友在成功注册成为牦牛出行用户后，您便可以获得5元推荐奖励；
            您的好友在领取本活动牦牛出行10元优惠券后7天内第一次体验牦牛出行网约车，并成功付款后，您可得到积分奖励。在活动期间，
            您可获得好友每次打车总金额3%的高额积分奖励，并可将积分兑换成等额优惠券，奖金优渥，等你来拿！
          </p>
          <p>
            <span>*</span>
            拥有相同设备（手机），账户，手机号，微信号，支付账号，银行卡号的用户将被视为同一用户（适用于您与您的好友），
            本活动仅对成功推荐好友完成并支付首次牦牛出行网约车订单的用户发放推荐奖励。
          </p>
          <p><span>*</span>针对违规推荐奖励的行为，将不予发放推荐奖励，追回相关奖励或封停账号、并依法追究其法律责任。</p>
        </div>
      </section>
    );
  }
}

export default AppComponent;
