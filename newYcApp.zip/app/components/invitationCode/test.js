require('normalize.css/normalize.css');
import React from 'react';
import {
  Container,
  Group,
  Slider,
} from 'amazeui-touch';
import  '../../style/App.css';
import '../../style/rule.css'
import  './invitate.css';
import pay_pic from '../../public/img/pay_pic.png';
import invite_pic from '../../public/img/invite_pic.png';
import textPic from '../../public/img/txt_pic.png';
import {
  render,
  Link
} from 'react-router'

class AppComponent extends React.Component {
  constructor(){
    super();
  }
  componentWillMount(){
    document.title='活动规则'
    document.body.style.background='#fff';
  }
  componentDidMount(){

  }
 onAction (index, direction) {
    console.log('激活的幻灯片编号：', index, '，滚动方向：', direction);
  };
  render() {
    return (
      <section className="bigBox">
        <Group
          header="默认"
          noPadded
        >
          <Slider  controls={false}  autoPlay={false}
            onAction={this.onAction.bind(this)}

          >
            <Slider.Item>
              <div className=" inviteCode" ref="test2">
                <header className="textPic textAlign"><img src={textPic} alt=""/></header>
                <section className="outsideBox">
                  <div className="bigBox">
                    <div className="middleBox marginCenter">
                      <div className="lastBox marginCenter">
                        <div className="lastBoxText">请输入好友邀请码</div>
                        <input  type="text" ref="ivcode"/>
                        {/*<img src={binding} onClick={this.bindCode.bind(this)} alt=""/>*/}
                      </div>
                    </div>
                  </div>
                </section>
              </div>
            </Slider.Item>
            <Slider.Item>
              <div className="inviteCode2" ref="test">
                <div className="rule-explain bgcolorW padding2 fontSize163">
                  <h3>活动说明</h3>
                  <p><span>*</span>未使用过牦牛出行的好友，可通过您分享的推荐链接领取牦牛出行优惠券（券有效期为7天）</p>
                  <p>
                    <span>*</span>
                    您的好友在成功注册成为牦牛出行用户后，您便可以获得5元推荐奖励；
                    您的好友在领取本活动牦牛出行10元优惠券后7天内第一次体验牦牛出行网约车，并成功付款后，您可得到积分奖励。在活动期间，
                    您可获得好友每次打车总金额3%的高额积分奖励，并可将积分兑换成等额优惠券，奖金优渥，等你来拿！
                  </p>
                  <p>
                    <span>*</span>
                    拥有相同设备（手机），账户，手机号，微信号，支付账号，银行卡号的用户将被视为同一用户（适用于您与您的好友），
                    本活动仅对成功推荐好友完成并支付首次牦牛出行网约车订单的用户发放推荐奖励。
                  </p>
                  <p><span>*</span>针对违规推荐奖励的行为，将不予发放推荐奖励，追回相关奖励或封停账号、并依法追究其法律责任。</p>
                </div>
              </div>
            </Slider.Item>
          </Slider>
        </Group>

      </section>
    );
  }
}

export default AppComponent;
